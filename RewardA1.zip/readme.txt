1 Download both files: the last version and the Patreon reward.
2 Unzip them in the same folder.
3 Follow the example, or the images won't show.
4 Start the game.
5 Load a saved game or start a new one.
6 Go to Computer, then Config.
7 Enable Patreon content.
8 You can check which version by opening the 'Patreon' folder.
9 Enable your version, and that's it.
10 You will see a new floor at the mall.

Your folder and files should be:

folder/TSGE.html
folder/vids/
folder/imgs/
folder/patreon/versionA1